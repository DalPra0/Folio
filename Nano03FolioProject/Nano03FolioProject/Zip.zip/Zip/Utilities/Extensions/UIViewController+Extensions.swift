//
//  UIViewController+Extensions.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit
import SwiftUI

extension UIViewController {
    
    // MARK: - SwiftUI Presentation
    
    /// Apresenta uma view SwiftUI modalmente
    func presentSwiftUIView<Content: View>(
        _ view: Content,
        animated: Bool = true,
        completion: (() -> Void)? = nil
    ) {
        let hostingController = UIHostingController(rootView: view)
        present(hostingController, animated: animated, completion: completion)
    }
    
    /// Push uma view SwiftUI no navigation controller
    func pushSwiftUIView<Content: View>(_ view: Content, animated: Bool = true) {
        let hostingController = UIHostingController(rootView: view)
        navigationController?.pushViewController(hostingController, animated: animated)
    }
    
    // MARK: - Alert Helpers
    
    /// Mostra um alert simples
    func showAlert(
        title: String,
        message: String,
        buttonTitle: String = "OK",
        completion: (() -> Void)? = nil
    ) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: buttonTitle, style: .default) { _ in
            completion?()
        })
        present(alert, animated: true)
    }
    
    /// Mostra um alert de confirmação
    func showConfirmation(
        title: String,
        message: String,
        confirmTitle: String = "Confirmar",
        cancelTitle: String = "Cancelar",
        onConfirm: @escaping () -> Void
    ) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: cancelTitle, style: .cancel))
        alert.addAction(UIAlertAction(title: confirmTitle, style: .default) { _ in
            onConfirm()
        })
        
        present(alert, animated: true)
    }
    
    /// Mostra um alert destrutivo (ex: deletar)
    func showDestructiveAlert(
        title: String,
        message: String,
        destructiveTitle: String = "Deletar",
        onConfirm: @escaping () -> Void
    ) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel))
        alert.addAction(UIAlertAction(title: destructiveTitle, style: .destructive) { _ in
            onConfirm()
        })
        
        present(alert, animated: true)
    }
    
    // MARK: - Loading Indicator
    
    private static var loadingView: UIView?
    private static var spinner: UIActivityIndicatorView?
    
    /// Mostra um loading overlay
    func showLoading() {
        guard Self.loadingView == nil else { return }
        
        let loadingView = UIView(frame: view.bounds)
        loadingView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        loadingView.translatesAutoresizingMaskIntoConstraints = false
        
        let spinner = UIActivityIndicatorView(style: .large)
        spinner.color = .white
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        
        loadingView.addSubview(spinner)
        view.addSubview(loadingView)
        
        NSLayoutConstraint.activate([
            loadingView.topAnchor.constraint(equalTo: view.topAnchor),
            loadingView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            loadingView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            loadingView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            spinner.centerXAnchor.constraint(equalTo: loadingView.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: loadingView.centerYAnchor)
        ])
        
        Self.loadingView = loadingView
        Self.spinner = spinner
    }
    
    /// Remove o loading overlay
    func hideLoading() {
        Self.spinner?.stopAnimating()
        Self.loadingView?.removeFromSuperview()
        Self.loadingView = nil
        Self.spinner = nil
    }
    
    // MARK: - Keyboard
    
    /// Adiciona gesture para esconder o teclado ao tocar fora
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
}
