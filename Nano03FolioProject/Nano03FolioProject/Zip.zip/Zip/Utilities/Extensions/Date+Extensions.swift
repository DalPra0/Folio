//
//  Date+Extensions.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation

extension Date {
    
    // MARK: - Formatters
    
    /// Retorna data formatada (ex: "1 de outubro de 2025")
    func formatted(style: DateFormatter.Style = .long) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = style
        formatter.timeStyle = .none
        formatter.locale = Locale(identifier: "pt_BR")
        return formatter.string(from: self)
    }
    
    /// Retorna data e hora formatadas
    func formattedWithTime(dateStyle: DateFormatter.Style = .medium, timeStyle: DateFormatter.Style = .short) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = dateStyle
        formatter.timeStyle = timeStyle
        formatter.locale = Locale(identifier: "pt_BR")
        return formatter.string(from: self)
    }
    
    /// Retorna tempo relativo (ex: "há 2 dias", "ontem", "hoje")
    func relativeFormatted() -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.unitsStyle = .full
        return formatter.localizedString(for: self, relativeTo: Date())
    }
    
    // MARK: - Comparisons
    
    /// Verifica se é hoje
    var isToday: Bool {
        Calendar.current.isDateInToday(self)
    }
    
    /// Verifica se é ontem
    var isYesterday: Bool {
        Calendar.current.isDateInYesterday(self)
    }
    
    /// Verifica se é amanhã
    var isTomorrow: Bool {
        Calendar.current.isDateInTomorrow(self)
    }
    
    /// Verifica se é na mesma semana
    var isThisWeek: Bool {
        Calendar.current.isDate(self, equalTo: Date(), toGranularity: .weekOfYear)
    }
    
    /// Verifica se é no mesmo mês
    var isThisMonth: Bool {
        Calendar.current.isDate(self, equalTo: Date(), toGranularity: .month)
    }
    
    /// Verifica se é no mesmo ano
    var isThisYear: Bool {
        Calendar.current.isDate(self, equalTo: Date(), toGranularity: .year)
    }
    
    // MARK: - Calculations
    
    /// Retorna quantos dias atrás foi
    var daysAgo: Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.day], from: self, to: Date())
        return components.day ?? 0
    }
    
    /// Adiciona dias à data
    func adding(days: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: days, to: self) ?? self
    }
    
    /// Adiciona meses à data
    func adding(months: Int) -> Date {
        Calendar.current.date(byAdding: .month, value: months, to: self) ?? self
    }
    
    /// Adiciona anos à data
    func adding(years: Int) -> Date {
        Calendar.current.date(byAdding: .year, value: years, to: self) ?? self
    }
    
    // MARK: - Components
    
    /// Retorna o dia do mês
    var day: Int {
        Calendar.current.component(.day, from: self)
    }
    
    /// Retorna o mês
    var month: Int {
        Calendar.current.component(.month, from: self)
    }
    
    /// Retorna o ano
    var year: Int {
        Calendar.current.component(.year, from: self)
    }
    
    /// Retorna a hora
    var hour: Int {
        Calendar.current.component(.hour, from: self)
    }
    
    /// Retorna os minutos
    var minute: Int {
        Calendar.current.component(.minute, from: self)
    }
}
