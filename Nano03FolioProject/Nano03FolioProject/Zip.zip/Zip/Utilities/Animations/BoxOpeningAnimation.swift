//
//  BoxOpeningAnimation.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit

/// Animação customizada de abertura da caixa de chá
class BoxOpeningAnimation {
    
    // MARK: - Properties
    private weak var containerView: UIView?
    private var boxImageView: UIImageView?
    private var overlayView: UIView?
    
    // MARK: - Public Methods
    
    /// Executa a animação de abertura da caixa
    /// - Parameters:
    ///   - sourceCell: A célula da caixa que será animada
    ///   - containerView: A view container onde a animação acontecerá (geralmente a window)
    ///   - completion: Callback quando a animação terminar
    func animate(
        from sourceCell: UICollectionViewCell,
        in containerView: UIView,
        completion: @escaping () -> Void
    ) {
        self.containerView = containerView
        
        setupAnimation(from: sourceCell, in: containerView)
        performAnimation(completion: completion)
    }
    
    // MARK: - Private Methods
    
    private func setupAnimation(from sourceCell: UICollectionViewCell, in containerView: UIView) {
        // Criar overlay escuro
        let overlay = UIView(frame: containerView.bounds)
        overlay.backgroundColor = .black
        overlay.alpha = 0
        containerView.addSubview(overlay)
        self.overlayView = overlay
        
        // Pegar snapshot da célula original
        guard let cellSnapshot = sourceCell.asImage() else { return }
        
        // Criar imageView para animar
        let imageView = UIImageView(image: cellSnapshot)
        imageView.contentMode = .scaleAspectFit
        
        // Posição inicial (onde estava a célula)
        let cellFrameInContainer = sourceCell.convert(sourceCell.bounds, to: containerView)
        imageView.frame = cellFrameInContainer
        
        containerView.addSubview(imageView)
        self.boxImageView = imageView
    }
    
    private func performAnimation(completion: @escaping () -> Void) {
        guard let boxImageView = boxImageView,
              let overlayView = overlayView,
              let containerView = containerView else {
            completion()
            return
        }
        
        // Fase 1: Fade do overlay e crescimento da caixa (0.4s)
        UIView.animate(withDuration: 0.4, delay: 0, options: .curveEaseOut) {
            overlayView.alpha = 0.7
            
            // Mover para o centro e aumentar
            let finalSize = CGSize(width: 200, height: 200)
            let centerX = containerView.bounds.midX
            let centerY = containerView.bounds.midY
            
            boxImageView.frame = CGRect(
                x: centerX - finalSize.width / 2,
                y: centerY - finalSize.height / 2,
                width: finalSize.width,
                height: finalSize.height
            )
        }
        
        // Fase 2: "Abrir" a caixa com rotação e escala (0.3s)
        UIView.animate(withDuration: 0.3, delay: 0.4, options: .curveEaseInOut) {
            // Simular abertura com rotação e escala
            boxImageView.transform = CGAffineTransform(rotationAngle: .pi / 8)
                .scaledBy(x: 1.2, y: 1.2)
            boxImageView.alpha = 0.8
        }
        
        // Fase 3: Fade out completo (0.2s)
        UIView.animate(withDuration: 0.2, delay: 0.7, options: .curveEaseIn) {
            boxImageView.alpha = 0
            overlayView.alpha = 0
        } completion: { _ in
            // Limpar views
            boxImageView.removeFromSuperview()
            overlayView.removeFromSuperview()
            
            // Callback
            completion()
        }
    }
}

// MARK: - Usage Extension
extension HomeViewController {
    
    /// Helper para executar a animação da caixa abrindo
    func animateBoxOpening(
        from cell: UICollectionViewCell,
        completion: @escaping () -> Void
    ) {
        guard let window = view.window else {
            completion()
            return
        }
        
        let animation = BoxOpeningAnimation()
        animation.animate(from: cell, in: window, completion: completion)
    }
}
