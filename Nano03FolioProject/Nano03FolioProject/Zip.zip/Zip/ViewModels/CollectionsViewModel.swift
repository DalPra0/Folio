//
//  CollectionsViewModel.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation
import Combine

/// ViewModel para gerenciar as coleções de chá
class CollectionsViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var collections: [TeaCollection] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    // MARK: - Private Properties
    private var cancellables = Set<AnyCancellable>()
    // TODO: Adicionar CoreDataManager e FirebaseManager quando estiverem prontos
    
    // MARK: - Initialization
    init() {
        loadCollections()
    }
    
    // MARK: - Public Methods
    
    /// Carrega todas as coleções
    func loadCollections() {
        isLoading = true
        
        // TODO: Carregar do CoreData
        // Por enquanto, usando dados de exemplo
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            self?.collections = TeaCollection.sampleCollections
            self?.isLoading = false
        }
    }
    
    /// Adiciona uma nova coleção
    func addCollection(name: String, boxColor: Int) {
        let newCollection = TeaCollection(name: name, boxColor: boxColor)
        collections.append(newCollection)
        
        // TODO: Salvar no CoreData e sincronizar com Firebase
    }
    
    /// Remove uma coleção
    func deleteCollection(_ collection: TeaCollection) {
        collections.removeAll { $0.id == collection.id }
        
        // TODO: Remover do CoreData e Firebase
    }
    
    /// Atualiza uma coleção existente
    func updateCollection(_ collection: TeaCollection) {
        if let index = collections.firstIndex(where: { $0.id == collection.id }) {
            collections[index] = collection
        }
        
        // TODO: Atualizar no CoreData e Firebase
    }
    
    /// Busca uma coleção por ID
    func getCollection(by id: UUID) -> TeaCollection? {
        collections.first { $0.id == id }
    }
}
