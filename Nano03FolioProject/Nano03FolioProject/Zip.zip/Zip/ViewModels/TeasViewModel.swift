//
//  TeasViewModel.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation
import Combine

/// ViewModel para gerenciar os chás dentro de uma coleção
class TeasViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var teas: [Tea] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var searchText: String = ""
    
    // MARK: - Private Properties
    private var cancellables = Set<AnyCancellable>()
    private let collectionId: UUID
    // TODO: Adicionar CoreDataManager quando estiver pronto
    
    // MARK: - Computed Properties
    var filteredTeas: [Tea] {
        if searchText.isEmpty {
            return teas
        }
        return teas.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
    }
    
    // MARK: - Initialization
    init(collectionId: UUID) {
        self.collectionId = collectionId
        loadTeas()
    }
    
    // MARK: - Public Methods
    
    /// Carrega os chás da coleção específica
    func loadTeas() {
        isLoading = true
        
        // TODO: Carregar do CoreData baseado no collectionId
        // Por enquanto, usando dados de exemplo
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            self?.teas = Tea.sampleTeas
            self?.isLoading = false
        }
    }
    
    /// Adiciona um novo chá
    func addTea(name: String, type: TeaType, variant: Int, notes: String?) {
        let newTea = Tea(
            name: name,
            type: type,
            variant: variant,
            notes: notes,
            collectionId: collectionId
        )
        teas.append(newTea)
        
        // TODO: Salvar no CoreData e sincronizar com Firebase
    }
    
    /// Remove um chá
    func deleteTea(_ tea: Tea) {
        teas.removeAll { $0.id == tea.id }
        
        // TODO: Remover do CoreData e Firebase
    }
    
    /// Atualiza um chá existente
    func updateTea(_ tea: Tea) {
        if let index = teas.firstIndex(where: { $0.id == tea.id }) {
            teas[index] = tea
        }
        
        // TODO: Atualizar no CoreData e Firebase
    }
    
    /// Toggle favorito
    func toggleFavorite(_ tea: Tea) {
        if let index = teas.firstIndex(where: { $0.id == tea.id }) {
            teas[index].isFavorite.toggle()
            // TODO: Atualizar no CoreData
        }
    }
}
