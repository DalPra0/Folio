//
//  TeaType.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation

/// Tipos de chá disponíveis no app
enum TeaType: String, Codable, CaseIterable {
    case teaBag = "teaBag"      // Saquinho de chá
    case teaCup = "teaCup"      // Xícara de chá (feito em casa)
    
    var displayName: String {
        switch self {
        case .teaBag:
            return "Saquinho de Chá"
        case .teaCup:
            return "Xícara de Chá"
        }
    }
    
    /// Retorna o nome do asset baseado no tipo e variante
    /// - Parameter variant: Variante de 1 a 4
    /// - Returns: Nome do asset (ex: "teaBag1", "teaCup3")
    func assetName(variant: Int) -> String {
        return "\(self.rawValue)\(variant)"
    }
}
