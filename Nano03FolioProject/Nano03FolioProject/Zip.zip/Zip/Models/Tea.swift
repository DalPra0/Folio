//
//  Tea.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation

/// Model que representa um chá individual
struct Tea: Identifiable, Codable {
    let id: UUID
    var name: String
    var type: TeaType
    var variant: Int                // 1 a 4 (qual asset usar)
    var notes: String?
    var collectionId: UUID
    var dateAdded: Date
    var isFavorite: Bool
    
    init(
        id: UUID = UUID(),
        name: String,
        type: TeaType,
        variant: Int,
        notes: String? = nil,
        collectionId: UUID,
        dateAdded: Date = Date(),
        isFavorite: Bool = false
    ) {
        self.id = id
        self.name = name
        self.type = type
        self.variant = max(1, min(4, variant)) // Garante que seja entre 1-4
        self.notes = notes
        self.collectionId = collectionId
        self.dateAdded = dateAdded
        self.isFavorite = isFavorite
    }
    
    /// Retorna o nome completo do asset para exibição
    var assetName: String {
        type.assetName(variant: variant)
    }
}

// MARK: - Sample Data para testes
extension Tea {
    static var sampleTea: Tea {
        Tea(
            name: "Earl Grey",
            type: .teaBag,
            variant: 1,
            notes: "Chá preto com bergamota",
            collectionId: UUID()
        )
    }
    
    static var sampleTeas: [Tea] {
        [
            Tea(name: "Earl Grey", type: .teaBag, variant: 1, collectionId: UUID()),
            Tea(name: "Chá Verde", type: .teaCup, variant: 2, collectionId: UUID()),
            Tea(name: "Camomila", type: .teaBag, variant: 3, collectionId: UUID()),
            Tea(name: "Hortelã", type: .teaCup, variant: 4, collectionId: UUID())
        ]
    }
}
