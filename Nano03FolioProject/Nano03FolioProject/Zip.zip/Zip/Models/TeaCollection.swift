//
//  Collection.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation

/// Model que representa uma coleção (caixa) de chás
struct TeaCollection: Identifiable, Codable {
    let id: UUID
    var name: String
    var boxColor: Int               // 1 a 4 (qual cor de caixa usar)
    var dateCreated: Date
    var teas: [Tea]                 // Chás dentro desta coleção
    
    init(
        id: UUID = UUID(),
        name: String,
        boxColor: Int,
        dateCreated: Date = Date(),
        teas: [Tea] = []
    ) {
        self.id = id
        self.name = name
        self.boxColor = max(1, min(4, boxColor)) // Garante que seja entre 1-4
        self.dateCreated = dateCreated
        self.teas = teas
    }
    
    /// Retorna o nome do asset da caixa
    var boxAssetName: String {
        "box\(boxColor)"
    }
    
    /// Quantidade de chás na coleção
    var teaCount: Int {
        teas.count
    }
    
    /// Adiciona um chá à coleção
    mutating func addTea(_ tea: Tea) {
        teas.append(tea)
    }
    
    /// Remove um chá da coleção
    mutating func removeTea(_ tea: Tea) {
        teas.removeAll { $0.id == tea.id }
    }
}

// MARK: - Sample Data para testes
extension TeaCollection {
    static var sampleCollection: TeaCollection {
        TeaCollection(
            name: "Chás Favoritos",
            boxColor: 1,
            teas: Tea.sampleTeas
        )
    }
    
    static var sampleCollections: [TeaCollection] {
        [
            TeaCollection(name: "Chás da Manhã", boxColor: 1, teas: [Tea.sampleTeas[0]]),
            TeaCollection(name: "Chás Relaxantes", boxColor: 2, teas: [Tea.sampleTeas[2]]),
            TeaCollection(name: "Chás Verdes", boxColor: 3, teas: [Tea.sampleTeas[1]]),
            TeaCollection(name: "Chás Especiais", boxColor: 4, teas: [])
        ]
    }
}
