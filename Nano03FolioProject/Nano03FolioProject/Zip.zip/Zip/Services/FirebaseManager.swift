//
//  FirebaseManager.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation
// TODO: import Firebase quando instalar o pacote

/// Gerenciador do Firebase (Firestore + Auth)
class FirebaseManager {
    
    // MARK: - Singleton
    static let shared = FirebaseManager()
    
    private init() {
        // TODO: Configurar Firebase
        // FirebaseApp.configure()
    }
    
    // MARK: - Properties
    var currentUserId: String? {
        // TODO: return Auth.auth().currentUser?.uid
        return nil
    }
    
    var isUserLoggedIn: Bool {
        return currentUserId != nil
    }
    
    // MARK: - Authentication
    
    /// Faz login com email e senha
    func signIn(email: String, password: String, completion: @escaping (Result<String, Error>) -> Void) {
        // TODO: Implementar quando adicionar Firebase Auth
        /*
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            if let userId = authResult?.user.uid {
                completion(.success(userId))
            }
        }
        */
        
        // Mock para desenvolvimento
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            completion(.success("mock_user_id"))
        }
    }
    
    /// Cria uma nova conta
    func signUp(email: String, password: String, completion: @escaping (Result<String, Error>) -> Void) {
        // TODO: Implementar quando adicionar Firebase Auth
        /*
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            if let userId = authResult?.user.uid {
                completion(.success(userId))
            }
        }
        */
        
        // Mock para desenvolvimento
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            completion(.success("mock_user_id"))
        }
    }
    
    /// Faz logout
    func signOut() {
        // TODO: try Auth.auth().signOut()
        print("✅ Firebase: User signed out")
    }
    
    // MARK: - Firestore - Collections
    
    /// Salva uma coleção no Firestore
    func saveCollection(_ collection: TeaCollection, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let userId = currentUserId else {
            print("⚠️ Firebase: User not logged in")
            completion(.failure(NSError(domain: "FirebaseManager", code: 401, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])))
            return
        }
        
        // TODO: Implementar quando adicionar Firestore
        /*
        let db = Firestore.firestore()
        let collectionRef = db.collection("users").document(userId).collection("collections").document(collection.id.uuidString)
        
        let data: [String: Any] = [
            "name": collection.name,
            "boxColor": collection.boxColor,
            "dateCreated": Timestamp(date: collection.dateCreated)
        ]
        
        collectionRef.setData(data) { error in
            if let error = error {
                completion(.failure(error))
            } else {
                print("✅ Firebase: Collection saved")
                completion(.success(()))
            }
        }
        */
        
        // Mock
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            completion(.success(()))
        }
    }
    
    /// Busca todas as coleções do usuário
    func fetchCollections(completion: @escaping (Result<[TeaCollection], Error>) -> Void) {
        guard let userId = currentUserId else {
            print("⚠️ Firebase: User not logged in")
            completion(.failure(NSError(domain: "FirebaseManager", code: 401)))
            return
        }
        
        // TODO: Implementar quando adicionar Firestore
        /*
        let db = Firestore.firestore()
        db.collection("users").document(userId).collection("collections").getDocuments { snapshot, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            let collections = snapshot?.documents.compactMap { doc -> TeaCollection? in
                let data = doc.data()
                // Converter data para TeaCollection
                return nil
            } ?? []
            
            completion(.success(collections))
        }
        */
        
        // Mock
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            completion(.success([]))
        }
    }
    
    /// Deleta uma coleção do Firestore
    func deleteCollection(_ collectionId: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let userId = currentUserId else {
            print("⚠️ Firebase: User not logged in")
            completion(.failure(NSError(domain: "FirebaseManager", code: 401)))
            return
        }
        
        // TODO: Implementar quando adicionar Firestore
        /*
        let db = Firestore.firestore()
        db.collection("users").document(userId).collection("collections").document(collectionId.uuidString).delete { error in
            if let error = error {
                completion(.failure(error))
            } else {
                print("✅ Firebase: Collection deleted")
                completion(.success(()))
            }
        }
        */
        
        // Mock
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            completion(.success(()))
        }
    }
    
    // MARK: - Firestore - Teas
    
    /// Salva um chá no Firestore
    func saveTea(_ tea: Tea, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let userId = currentUserId else {
            print("⚠️ Firebase: User not logged in")
            completion(.failure(NSError(domain: "FirebaseManager", code: 401)))
            return
        }
        
        // TODO: Implementar quando adicionar Firestore
        // Similar à saveCollection
        
        // Mock
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            completion(.success(()))
        }
    }
    
    /// Busca chás de uma coleção
    func fetchTeas(for collectionId: UUID, completion: @escaping (Result<[Tea], Error>) -> Void) {
        guard let userId = currentUserId else {
            print("⚠️ Firebase: User not logged in")
            completion(.failure(NSError(domain: "FirebaseManager", code: 401)))
            return
        }
        
        // TODO: Implementar quando adicionar Firestore
        
        // Mock
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            completion(.success([]))
        }
    }
}
