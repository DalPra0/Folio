//
//  CoreDataManager.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import Foundation
import CoreData
import UIKit

/// Gerenciador centralizado do Core Data
class CoreDataManager {
    
    // MARK: - Singleton
    static let shared = CoreDataManager()
    
    private init() {}
    
    // MARK: - Core Data Stack
    
    /// Acesso ao container do AppDelegate
    private var persistentContainer: NSPersistentCloudKitContainer {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            fatalError("Unable to access AppDelegate")
        }
        return appDelegate.persistentContainer
    }
    
    /// Context principal (main thread)
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    /// Cria um background context para operações pesadas
    func newBackgroundContext() -> NSManagedObjectContext {
        return persistentContainer.newBackgroundContext()
    }
    
    // MARK: - Save Context
    
    /// Salva o contexto principal
    func saveContext() {
        let context = viewContext
        if context.hasChanges {
            do {
                try context.save()
                print("✅ CoreData: Context saved successfully")
            } catch {
                let nsError = error as NSError
                print("❌ CoreData: Error saving context - \(nsError), \(nsError.userInfo)")
            }
        }
    }
    
    /// Salva um contexto específico
    func save(context: NSManagedObjectContext) {
        if context.hasChanges {
            do {
                try context.save()
                print("✅ CoreData: Background context saved successfully")
            } catch {
                let nsError = error as NSError
                print("❌ CoreData: Error saving background context - \(nsError), \(nsError.userInfo)")
            }
        }
    }
    
    // MARK: - CRUD Operations para Collections
    
    /// Cria uma nova coleção no CoreData
    func createCollection(_ collection: TeaCollection) {
        let context = viewContext
        
        // TODO: Criar entidade CDCollection no .xcdatamodel
        // let cdCollection = CDCollection(context: context)
        // cdCollection.id = collection.id
        // cdCollection.name = collection.name
        // cdCollection.boxColor = Int16(collection.boxColor)
        // cdCollection.dateCreated = collection.dateCreated
        
        saveContext()
    }
    
    /// Busca todas as coleções
    func fetchCollections() -> [TeaCollection] {
        let context = viewContext
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "CDCollection")
        
        do {
            // TODO: Converter CDCollection para TeaCollection
            // let cdCollections = try context.fetch(fetchRequest) as? [CDCollection]
            // return cdCollections?.map { $0.toTeaCollection() } ?? []
            return []
        } catch {
            print("❌ CoreData: Error fetching collections - \(error)")
            return []
        }
    }
    
    /// Deleta uma coleção
    func deleteCollection(_ collection: TeaCollection) {
        let context = viewContext
        
        // TODO: Buscar e deletar a CDCollection correspondente
        
        saveContext()
    }
    
    // MARK: - CRUD Operations para Teas
    
    /// Cria um novo chá no CoreData
    func createTea(_ tea: Tea) {
        let context = viewContext
        
        // TODO: Criar entidade CDTea no .xcdatamodel
        // let cdTea = CDTea(context: context)
        // cdTea.id = tea.id
        // cdTea.name = tea.name
        // cdTea.type = tea.type.rawValue
        // cdTea.variant = Int16(tea.variant)
        // cdTea.notes = tea.notes
        // cdTea.collectionId = tea.collectionId
        // cdTea.dateAdded = tea.dateAdded
        // cdTea.isFavorite = tea.isFavorite
        
        saveContext()
    }
    
    /// Busca chás de uma coleção específica
    func fetchTeas(for collectionId: UUID) -> [Tea] {
        let context = viewContext
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "CDTea")
        fetchRequest.predicate = NSPredicate(format: "collectionId == %@", collectionId as CVarArg)
        
        do {
            // TODO: Converter CDTea para Tea
            // let cdTeas = try context.fetch(fetchRequest) as? [CDTea]
            // return cdTeas?.map { $0.toTea() } ?? []
            return []
        } catch {
            print("❌ CoreData: Error fetching teas - \(error)")
            return []
        }
    }
    
    /// Deleta um chá
    func deleteTea(_ tea: Tea) {
        let context = viewContext
        
        // TODO: Buscar e deletar o CDTea correspondente
        
        saveContext()
    }
}

// MARK: - TODO: Extensions de conversão
/*
extension CDCollection {
    func toTeaCollection() -> TeaCollection {
        return TeaCollection(
            id: self.id ?? UUID(),
            name: self.name ?? "",
            boxColor: Int(self.boxColor),
            dateCreated: self.dateCreated ?? Date(),
            teas: [] // Buscar teas separadamente
        )
    }
}

extension CDTea {
    func toTea() -> Tea {
        return Tea(
            id: self.id ?? UUID(),
            name: self.name ?? "",
            type: TeaType(rawValue: self.type ?? "") ?? .teaBag,
            variant: Int(self.variant),
            notes: self.notes,
            collectionId: self.collectionId ?? UUID(),
            dateAdded: self.dateAdded ?? Date(),
            isFavorite: self.isFavorite
        )
    }
}
*/
