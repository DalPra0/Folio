//
//  HomeViewController.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit
import Combine

/// Tela principal que exibe a estante com as coleções (caixas)
class HomeViewController: UIViewController {
    
    // MARK: - Properties
    private let viewModel = CollectionsViewModel()
    private var cancellables = Set<AnyCancellable>()
    
    private let fab = FloatingActionButton()
    
    // Collection View
    private lazy var collectionView: UICollectionView = {
        let layout = createLayout()
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.backgroundColor = .systemBackground
        cv.delegate = self
        cv.dataSource = self
        cv.register(CollectionCell.self, forCellWithReuseIdentifier: CollectionCell.identifier)
        return cv
    }()
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupBindings()
    }
    
    // MARK: - Setup
    private func setupUI() {
        title = "Minha Estante"
        view.backgroundColor = .systemBackground
        
        // Adicionar CollectionView
        view.addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        // Adicionar FAB
        fab.addToView(view)
        fab.addTarget(self, action: #selector(fabTapped), for: .touchUpInside)
    }
    
    private func setupBindings() {
        // Observar mudanças nas coleções
        viewModel.$collections
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.collectionView.reloadData()
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Layout
    private func createLayout() -> UICollectionViewLayout {
        // Layout simples de grid 2 colunas
        let itemSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(0.5),
            heightDimension: .fractionalHeight(1.0)
        )
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8)
        
        let groupSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(1.0),
            heightDimension: .absolute(200)
        )
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: 16, leading: 8, bottom: 16, trailing: 8)
        
        return UICollectionViewCompositionalLayout(section: section)
    }
    
    // MARK: - Actions
    @objc private func fabTapped() {
        // TODO: Apresentar tela de adicionar coleção (SwiftUI)
        print("FAB tapped - Adicionar coleção")
    }
}

// MARK: - UICollectionView DataSource
extension HomeViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.collections.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: CollectionCell.identifier,
            for: indexPath
        ) as? CollectionCell else {
            return UICollectionViewCell()
        }
        
        let collection = viewModel.collections[indexPath.item]
        cell.configure(with: collection)
        return cell
    }
}

// MARK: - UICollectionView Delegate
extension HomeViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let collection = viewModel.collections[indexPath.item]
        
        // Navegar para a tela de chás dentro da coleção
        let teaShelfVC = TeaShelfViewController(collection: collection)
        navigationController?.pushViewController(teaShelfVC, animated: true)
        
        // TODO: Adicionar animação da caixa abrindo
    }
}
