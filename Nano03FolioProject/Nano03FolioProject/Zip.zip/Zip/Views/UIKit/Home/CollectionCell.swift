//
//  CollectionCell.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit

/// Célula que representa uma coleção (caixa) na estante
class CollectionCell: UICollectionViewCell {
    
    static let identifier = "CollectionCell"
    
    // MARK: - UI Components
    private let boxImageView: UIImageView = {
        let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFit
        iv.clipsToBounds = true
        return iv
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
    
    private let teaCountLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.textColor = .secondaryLabel
        label.textAlignment = .center
        return label
    }()
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        contentView.backgroundColor = .secondarySystemBackground
        contentView.layer.cornerRadius = 12
        contentView.clipsToBounds = true
        
        // Adicionar sombra à célula
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 2)
        layer.shadowRadius = 4
        layer.shadowOpacity = 0.1
        layer.masksToBounds = false
        
        contentView.addSubview(boxImageView)
        contentView.addSubview(nameLabel)
        contentView.addSubview(teaCountLabel)
        
        NSLayoutConstraint.activate([
            // Box Image
            boxImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),
            boxImageView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            boxImageView.widthAnchor.constraint(equalToConstant: 80),
            boxImageView.heightAnchor.constraint(equalToConstant: 80),
            
            // Name Label
            nameLabel.topAnchor.constraint(equalTo: boxImageView.bottomAnchor, constant: 12),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            
            // Tea Count Label
            teaCountLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 4),
            teaCountLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            teaCountLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            teaCountLabel.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -12)
        ])
    }
    
    // MARK: - Configuration
    func configure(with collection: TeaCollection) {
        nameLabel.text = collection.name
        teaCountLabel.text = "\(collection.teaCount) chá\(collection.teaCount == 1 ? "" : "s")"
        
        // Carregar imagem da caixa
        // Por enquanto usando SF Symbol como placeholder
        // TODO: Substituir por assets reais quando tiver
        boxImageView.image = UIImage(systemName: "shippingbox.fill")
        boxImageView.tintColor = getColorForBox(variant: collection.boxColor)
    }
    
    // MARK: - Helper
    private func getColorForBox(variant: Int) -> UIColor {
        // Cores temporárias - substituir quando tiver os assets reais
        switch variant {
        case 1: return .systemBrown
        case 2: return .systemOrange
        case 3: return .systemGreen
        case 4: return .systemBlue
        default: return .systemBrown
        }
    }
    
    // MARK: - Reuse
    override func prepareForReuse() {
        super.prepareForReuse()
        boxImageView.image = nil
        nameLabel.text = nil
        teaCountLabel.text = nil
    }
}
