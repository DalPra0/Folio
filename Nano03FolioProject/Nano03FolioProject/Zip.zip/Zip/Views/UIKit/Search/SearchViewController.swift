//
//  SearchViewController.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit
import Combine

/// Tela de pesquisa de chás
class SearchViewController: UIViewController {
    
    // MARK: - Properties
    private let viewModel = TeasViewModel(collectionId: UUID()) // TODO: Buscar de todas as coleções
    private var cancellables = Set<AnyCancellable>()
    
    // Search Controller
    private let searchController: UISearchController = {
        let sc = UISearchController(searchResultsController: nil)
        sc.obscuresBackgroundDuringPresentation = false
        sc.searchBar.placeholder = "Buscar chá..."
        return sc
    }()
    
    // Table View
    private lazy var tableView: UITableView = {
        let tv = UITableView(frame: .zero, style: .insetGrouped)
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.delegate = self
        tv.dataSource = self
        tv.register(UITableViewCell.self, forCellReuseIdentifier: "TeaCell")
        return tv
    }()
    
    // Empty State View
    private lazy var emptyStateLabel: UILabel = {
        let label = UILabel()
        label.text = "Nenhum chá encontrado"
        label.textColor = .secondaryLabel
        label.font = .systemFont(ofSize: 18, weight: .medium)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        label.isHidden = true
        return label
    }()
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSearchController()
        setupBindings()
    }
    
    // MARK: - Setup
    private func setupUI() {
        title = "Pesquisar"
        view.backgroundColor = .systemBackground
        
        // Add TableView
        view.addSubview(tableView)
        view.addSubview(emptyStateLabel)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            emptyStateLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyStateLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
    
    private func setupSearchController() {
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        searchController.searchResultsUpdater = self
        definesPresentationContext = true
    }
    
    private func setupBindings() {
        // Observar mudanças nos chás filtrados
        viewModel.$searchText
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.updateUI()
            }
            .store(in: &cancellables)
        
        viewModel.$teas
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.updateUI()
            }
            .store(in: &cancellables)
    }
    
    private func updateUI() {
        tableView.reloadData()
        emptyStateLabel.isHidden = !viewModel.filteredTeas.isEmpty || viewModel.searchText.isEmpty
    }
}

// MARK: - UITableView DataSource
extension SearchViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.filteredTeas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TeaCell", for: indexPath)
        let tea = viewModel.filteredTeas[indexPath.row]
        
        var config = cell.defaultContentConfiguration()
        config.text = tea.name
        config.secondaryText = tea.type.displayName
        config.image = UIImage(systemName: tea.isFavorite ? "heart.fill" : "heart")
        cell.contentConfiguration = config
        
        return cell
    }
}

// MARK: - UITableView Delegate
extension SearchViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let tea = viewModel.filteredTeas[indexPath.row]
        
        // Navegar para detalhes do chá
        let detailVC = TeaDetailViewController(tea: tea)
        navigationController?.pushViewController(detailVC, animated: true)
    }
}

// MARK: - UISearchResultsUpdating
extension SearchViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        viewModel.searchText = searchController.searchBar.text ?? ""
    }
}
