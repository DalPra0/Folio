//
//  TeaCell.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit

/// Célula que exibe um chá individual (xícara ou saquinho)
class TeaCell: UICollectionViewCell {
    
    static let identifier = "TeaCell"
    
    // MARK: - UI Components
    private let containerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .systemBackground
        view.layer.cornerRadius = 12
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
        view.layer.shadowOpacity = 0.1
        return view
    }()
    
    private let teaImageView: UIImageView = {
        let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFit
        iv.tintColor = .systemBrown
        return iv
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .semibold)
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
    
    private let typeLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 12, weight: .regular)
        label.textAlignment = .center
        label.textColor = .systemGray
        return label
    }()
    
    private let favoriteIcon: UIImageView = {
        let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFit
        iv.tintColor = .systemYellow
        iv.image = UIImage(systemName: "star.fill")
        iv.isHidden = true
        return iv
    }()
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        contentView.addSubview(containerView)
        [teaImageView, nameLabel, typeLabel, favoriteIcon].forEach {
            containerView.addSubview($0)
        }
        
        NSLayoutConstraint.activate([
            // Container
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            
            // Favorite Icon
            favoriteIcon.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 8),
            favoriteIcon.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -8),
            favoriteIcon.widthAnchor.constraint(equalToConstant: 16),
            favoriteIcon.heightAnchor.constraint(equalToConstant: 16),
            
            // Tea Image
            teaImageView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 20),
            teaImageView.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            teaImageView.widthAnchor.constraint(equalToConstant: 60),
            teaImageView.heightAnchor.constraint(equalToConstant: 60),
            
            // Name Label
            nameLabel.topAnchor.constraint(equalTo: teaImageView.bottomAnchor, constant: 12),
            nameLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 8),
            nameLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -8),
            
            // Type Label
            typeLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 4),
            typeLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 8),
            typeLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -8),
            typeLabel.bottomAnchor.constraint(lessThanOrEqualTo: containerView.bottomAnchor, constant: -12)
        ])
    }
    
    // MARK: - Configure
    func configure(with tea: Tea) {
        nameLabel.text = tea.name
        typeLabel.text = tea.type.displayName
        favoriteIcon.isHidden = !tea.isFavorite
        
        // Configurar imagem (por enquanto usando SF Symbols como placeholder)
        // TODO: Substituir por assets reais quando estiverem prontos
        switch tea.type {
        case .teaBag:
            teaImageView.image = UIImage(systemName: "square.fill")
        case .teaCup:
            teaImageView.image = UIImage(systemName: "cup.and.saucer.fill")
        }
        
        // Aplicar cor baseada na variante (placeholder)
        let colors: [UIColor] = [.systemBrown, .systemGreen, .systemOrange, .systemPurple]
        teaImageView.tintColor = colors[min(tea.variant - 1, colors.count - 1)]
    }
    
    // MARK: - Reuse
    override func prepareForReuse() {
        super.prepareForReuse()
        teaImageView.image = nil
        nameLabel.text = nil
        typeLabel.text = nil
        favoriteIcon.isHidden = true
    }
}
