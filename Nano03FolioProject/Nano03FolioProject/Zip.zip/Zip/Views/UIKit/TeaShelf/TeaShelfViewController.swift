//
//  TeaShelfViewController.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit
import Combine

/// Tela que exibe os chás dentro de uma coleção específica (estante de chás)
class TeaShelfViewController: UIViewController {
    
    // MARK: - Properties
    private let viewModel: TeasViewModel
    private let collection: TeaCollection
    private var cancellables = Set<AnyCancellable>()
    
    private let fab = FloatingActionButton()
    
    // Collection View
    private lazy var collectionView: UICollectionView = {
        let layout = createLayout()
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.backgroundColor = .systemBackground
        cv.delegate = self
        cv.dataSource = self
        cv.register(TeaCell.self, forCellWithReuseIdentifier: TeaCell.identifier)
        return cv
    }()
    
    private let emptyStateView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()
    
    private let emptyLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Nenhum chá nesta coleção\nToque no + para adicionar"
        label.textAlignment = .center
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = .systemGray
        return label
    }()
    
    // MARK: - Initialization
    init(collection: TeaCollection) {
        self.collection = collection
        self.viewModel = TeasViewModel(collectionId: collection.id)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupBindings()
        viewModel.loadTeas()
    }
    
    // MARK: - Setup
    private func setupUI() {
        title = collection.name
        view.backgroundColor = .systemBackground
        
        // Adicionar CollectionView
        view.addSubview(collectionView)
        
        // Adicionar Empty State
        view.addSubview(emptyStateView)
        emptyStateView.addSubview(emptyLabel)
        
        NSLayoutConstraint.activate([
            // CollectionView
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            // Empty State
            emptyStateView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyStateView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            emptyStateView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            emptyStateView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            
            emptyLabel.topAnchor.constraint(equalTo: emptyStateView.topAnchor),
            emptyLabel.leadingAnchor.constraint(equalTo: emptyStateView.leadingAnchor),
            emptyLabel.trailingAnchor.constraint(equalTo: emptyStateView.trailingAnchor),
            emptyLabel.bottomAnchor.constraint(equalTo: emptyStateView.bottomAnchor)
        ])
        
        // Adicionar FAB
        fab.addToView(view)
        fab.addTarget(self, action: #selector(fabTapped), for: .touchUpInside)
    }
    
    private func setupBindings() {
        viewModel.$teas
            .receive(on: DispatchQueue.main)
            .sink { [weak self] teas in
                self?.collectionView.reloadData()
                self?.updateEmptyState(isEmpty: teas.isEmpty)
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Layout
    private func createLayout() -> UICollectionViewLayout {
        // Grid 2 colunas para exibir as xícaras/saquinhos
        let itemSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(0.5),
            heightDimension: .fractionalHeight(1.0)
        )
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8)
        
        let groupSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(1.0),
            heightDimension: .absolute(180)
        )
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: 16, leading: 8, bottom: 16, trailing: 8)
        
        return UICollectionViewCompositionalLayout(section: section)
    }
    
    // MARK: - Helpers
    private func updateEmptyState(isEmpty: Bool) {
        emptyStateView.isHidden = !isEmpty
        collectionView.isHidden = isEmpty
    }
    
    // MARK: - Actions
    @objc private func fabTapped() {
        // TODO: Apresentar tela de adicionar chá (SwiftUI)
        print("FAB tapped - Adicionar chá na coleção: \(collection.name)")
    }
}

// MARK: - UICollectionView DataSource
extension TeaShelfViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.teas.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: TeaCell.identifier,
            for: indexPath
        ) as? TeaCell else {
            return UICollectionViewCell()
        }
        
        let tea = viewModel.teas[indexPath.item]
        cell.configure(with: tea)
        return cell
    }
}

// MARK: - UICollectionView Delegate
extension TeaShelfViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let tea = viewModel.teas[indexPath.item]
        
        // Navegar para detalhes do chá
        let detailVC = TeaDetailViewController(tea: tea)
        navigationController?.pushViewController(detailVC, animated: true)
    }
}
