//
//  FloatingActionButton.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit

/// Botão flutuante customizável (FAB - Floating Action Button)
class FloatingActionButton: UIButton {
    
    // MARK: - Properties
    private let shadowLayer = CAShapeLayer()
    
    // MARK: - Initialization
    init(image: UIImage? = UIImage(systemName: "plus")) {
        super.init(frame: .zero)
        setupButton(image: image)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupButton(image: UIImage?) {
        // Configuração visual
        backgroundColor = UIColor(named: "AccentColor") ?? .systemBrown
        tintColor = .white
        setImage(image, for: .normal)
        
        // Tornar circular
        layer.cornerRadius = 28 // Assumindo button de 56x56
        clipsToBounds = true
        
        // Sombra
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 4)
        layer.shadowRadius = 8
        layer.shadowOpacity = 0.3
        
        // Configuração da imagem
        imageView?.contentMode = .scaleAspectFit
        contentVerticalAlignment = .fill
        contentHorizontalAlignment = .fill
        imageEdgeInsets = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        
        // Adicionar animação no toque
        addTarget(self, action: #selector(buttonPressed), for: .touchDown)
        addTarget(self, action: #selector(buttonReleased), for: [.touchUpInside, .touchUpOutside, .touchCancel])
    }
    
    // MARK: - Animations
    @objc private func buttonPressed() {
        UIView.animate(withDuration: 0.1) {
            self.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
        }
    }
    
    @objc private func buttonReleased() {
        UIView.animate(withDuration: 0.1) {
            self.transform = .identity
        }
    }
    
    // MARK: - Public Methods
    
    /// Adiciona o FAB a uma view com constraints
    func addToView(_ view: UIView, bottomOffset: CGFloat = 100, trailingOffset: CGFloat = 24) {
        view.addSubview(self)
        translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalToConstant: 56),
            heightAnchor.constraint(equalToConstant: 56),
            trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -trailingOffset),
            bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -bottomOffset)
        ])
    }
    
    /// Animação de entrada (fade in + scale)
    func animateIn() {
        alpha = 0
        transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.5) {
            self.alpha = 1
            self.transform = .identity
        }
    }
}
