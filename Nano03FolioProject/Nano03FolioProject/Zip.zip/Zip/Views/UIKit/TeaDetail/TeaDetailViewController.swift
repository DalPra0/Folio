//
//  TeaDetailViewController.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit

/// Tela de detalhes de um chá específico
class TeaDetailViewController: UIViewController {
    
    // MARK: - Properties
    private let tea: Tea
    
    // MARK: - UI Components
    private let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    private let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let teaImageView: UIImageView = {
        let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFit
        iv.tintColor = .systemBrown
        return iv
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 28, weight: .bold)
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    private let typeLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textAlignment = .center
        label.textColor = .systemGray
        return label
    }()
    
    private let notesContainerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .systemGray6
        view.layer.cornerRadius = 12
        return view
    }()
    
    private let notesHeaderLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.text = "Notas"
        return label
    }()
    
    private let notesLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.textColor = .label
        label.numberOfLines = 0
        return label
    }()
    
    private let dateLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.textAlignment = .center
        label.textColor = .systemGray2
        return label
    }()
    
    private lazy var favoriteButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        let config = UIImage.SymbolConfiguration(pointSize: 24, weight: .medium)
        button.setImage(UIImage(systemName: "star", withConfiguration: config), for: .normal)
        button.setImage(UIImage(systemName: "star.fill", withConfiguration: config), for: .selected)
        button.tintColor = .systemYellow
        return button
    }()
    
    // MARK: - Initialization
    init(tea: Tea) {
        self.tea = tea
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        configureWithTea()
        setupActions()
    }
    
    // MARK: - Setup
    private func setupUI() {
        title = "Detalhes"
        view.backgroundColor = .systemBackground
        
        // Adicionar botão de editar
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .edit,
            target: self,
            action: #selector(editTapped)
        )
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        [teaImageView, nameLabel, typeLabel, favoriteButton, notesContainerView, dateLabel].forEach {
            contentView.addSubview($0)
        }
        
        [notesHeaderLabel, notesLabel].forEach {
            notesContainerView.addSubview($0)
        }
        
        NSLayoutConstraint.activate([
            // ScrollView
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            // ContentView
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            // Tea Image
            teaImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 40),
            teaImageView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            teaImageView.widthAnchor.constraint(equalToConstant: 150),
            teaImageView.heightAnchor.constraint(equalToConstant: 150),
            
            // Name Label
            nameLabel.topAnchor.constraint(equalTo: teaImageView.bottomAnchor, constant: 24),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            // Type Label
            typeLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 8),
            typeLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            typeLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            // Favorite Button
            favoriteButton.topAnchor.constraint(equalTo: typeLabel.bottomAnchor, constant: 16),
            favoriteButton.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            favoriteButton.widthAnchor.constraint(equalToConstant: 44),
            favoriteButton.heightAnchor.constraint(equalToConstant: 44),
            
            // Notes Container
            notesContainerView.topAnchor.constraint(equalTo: favoriteButton.bottomAnchor, constant: 24),
            notesContainerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            notesContainerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            // Notes Header
            notesHeaderLabel.topAnchor.constraint(equalTo: notesContainerView.topAnchor, constant: 16),
            notesHeaderLabel.leadingAnchor.constraint(equalTo: notesContainerView.leadingAnchor, constant: 16),
            notesHeaderLabel.trailingAnchor.constraint(equalTo: notesContainerView.trailingAnchor, constant: -16),
            
            // Notes Label
            notesLabel.topAnchor.constraint(equalTo: notesHeaderLabel.bottomAnchor, constant: 8),
            notesLabel.leadingAnchor.constraint(equalTo: notesContainerView.leadingAnchor, constant: 16),
            notesLabel.trailingAnchor.constraint(equalTo: notesContainerView.trailingAnchor, constant: -16),
            notesLabel.bottomAnchor.constraint(equalTo: notesContainerView.bottomAnchor, constant: -16),
            
            // Date Label
            dateLabel.topAnchor.constraint(equalTo: notesContainerView.bottomAnchor, constant: 24),
            dateLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            dateLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            dateLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -40)
        ])
    }
    
    private func setupActions() {
        favoriteButton.addTarget(self, action: #selector(favoriteTapped), for: .touchUpInside)
    }
    
    // MARK: - Configuration
    private func configureWithTea() {
        nameLabel.text = tea.name
        typeLabel.text = tea.type.displayName
        favoriteButton.isSelected = tea.isFavorite
        
        // Configurar notas
        if let notes = tea.notes, !notes.isEmpty {
            notesLabel.text = notes
        } else {
            notesLabel.text = "Nenhuma nota adicionada"
            notesLabel.textColor = .systemGray3
        }
        
        // Configurar data
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .none
        formatter.locale = Locale(identifier: "pt_BR")
        dateLabel.text = "Adicionado em \(formatter.string(from: tea.dateAdded))"
        
        // Configurar imagem (placeholder)
        switch tea.type {
        case .teaBag:
            teaImageView.image = UIImage(systemName: "square.fill")
        case .teaCup:
            teaImageView.image = UIImage(systemName: "cup.and.saucer.fill")
        }
        
        // Aplicar cor baseada na variante
        let colors: [UIColor] = [.systemBrown, .systemGreen, .systemOrange, .systemPurple]
        teaImageView.tintColor = colors[min(tea.variant - 1, colors.count - 1)]
    }
    
    // MARK: - Actions
    @objc private func editTapped() {
        // TODO: Apresentar tela de edição (SwiftUI)
        print("Edit tea tapped")
    }
    
    @objc private func favoriteTapped() {
        favoriteButton.isSelected.toggle()
        
        // TODO: Atualizar no CoreData e Firebase
        print("Favorite status: \(favoriteButton.isSelected)")
    }
}
