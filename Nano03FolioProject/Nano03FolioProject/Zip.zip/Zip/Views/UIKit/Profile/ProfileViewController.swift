//
//  ProfileViewController.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import UIKit

/// Tela de perfil do usuário
class ProfileViewController: UIViewController {
    
    // MARK: - UI Components
    private let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    private let contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let profileImageView: UIImageView = {
        let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.layer.cornerRadius = 50
        iv.backgroundColor = .systemGray5
        iv.image = UIImage(systemName: "person.circle.fill")
        iv.tintColor = .systemGray3
        return iv
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.textAlignment = .center
        label.text = "Visitante"
        return label
    }()
    
    private let loginButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Fazer Login", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.backgroundColor = UIColor(named: "AccentColor") ?? .systemBrown
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 12
        return button
    }()
    
    private let warningView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .systemYellow.withAlphaComponent(0.2)
        view.layer.cornerRadius = 12
        return view
    }()
    
    private let warningLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = .systemOrange
        label.text = "⚠️ Você está usando o app sem login. Seus dados podem ser perdidos."
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    // MARK: - Properties
    private var isLoggedIn = false
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupActions()
        checkLoginStatus()
    }
    
    // MARK: - Setup
    private func setupUI() {
        title = "Perfil"
        view.backgroundColor = .systemBackground
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        [profileImageView, nameLabel, loginButton, warningView].forEach {
            contentView.addSubview($0)
        }
        warningView.addSubview(warningLabel)
        
        NSLayoutConstraint.activate([
            // ScrollView
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            // ContentView
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            // Profile Image
            profileImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 40),
            profileImageView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            profileImageView.widthAnchor.constraint(equalToConstant: 100),
            profileImageView.heightAnchor.constraint(equalToConstant: 100),
            
            // Name Label
            nameLabel.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 16),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            // Login Button
            loginButton.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 24),
            loginButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 40),
            loginButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -40),
            loginButton.heightAnchor.constraint(equalToConstant: 50),
            
            // Warning View
            warningView.topAnchor.constraint(equalTo: loginButton.bottomAnchor, constant: 24),
            warningView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            warningView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            warningView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -40),
            
            // Warning Label
            warningLabel.topAnchor.constraint(equalTo: warningView.topAnchor, constant: 16),
            warningLabel.leadingAnchor.constraint(equalTo: warningView.leadingAnchor, constant: 16),
            warningLabel.trailingAnchor.constraint(equalTo: warningView.trailingAnchor, constant: -16),
            warningLabel.bottomAnchor.constraint(equalTo: warningView.bottomAnchor, constant: -16)
        ])
    }
    
    private func setupActions() {
        loginButton.addTarget(self, action: #selector(loginButtonTapped), for: .touchUpInside)
    }
    
    // MARK: - Actions
    @objc private func loginButtonTapped() {
        // TODO: Apresentar tela de login (SwiftUI)
        print("Login button tapped")
        
        // Placeholder - simular login
        showLoginAlert()
    }
    
    private func showLoginAlert() {
        let alert = UIAlertController(
            title: "Login",
            message: "Funcionalidade de login será implementada",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    // MARK: - Helpers
    private func checkLoginStatus() {
        // TODO: Verificar status de login via FirebaseManager
        updateUI(isLoggedIn: isLoggedIn)
    }
    
    private func updateUI(isLoggedIn: Bool) {
        self.isLoggedIn = isLoggedIn
        
        if isLoggedIn {
            loginButton.setTitle("Sair", for: .normal)
            loginButton.backgroundColor = .systemRed
            warningView.isHidden = true
        } else {
            loginButton.setTitle("Fazer Login", for: .normal)
            loginButton.backgroundColor = UIColor(named: "AccentColor") ?? .systemBrown
            warningView.isHidden = false
        }
    }
}
