//
//  AddTeaView.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import SwiftUI

/// View SwiftUI para adicionar um novo chá
struct AddTeaView: View {
    // MARK: - Environment
    @Environment(\.dismiss) var dismiss
    
    // MARK: - State
    @State private var teaName: String = ""
    @State private var selectedType: TeaType = .teaBag
    @State private var selectedVariant: Int = 1
    @State private var notes: String = ""
    @State private var isFavorite: Bool = false
    @State private var showingAlert: Bool = false
    
    // MARK: - Properties
    let collectionId: UUID
    
    // MARK: - Callback
    var onSave: ((String, TeaType, Int, String?) -> Void)?
    
    // MARK: - Body
    var body: some View {
        NavigationView {
            Form {
                // Nome do Chá
                Section(header: Text("Nome do Chá")) {
                    TextField("Ex: Earl Grey", text: $teaName)
                        .autocapitalization(.words)
                }
                
                // Tipo de Chá
                Section(header: Text("Tipo de Chá")) {
                    Picker("Tipo", selection: $selectedType) {
                        ForEach(TeaType.allCases, id: \.self) { type in
                            Text(type.displayName).tag(type)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                
                // Variante (cor/estilo)
                Section(header: Text(selectedType == .teaBag ? "Escolha o Saquinho" : "Escolha a Xícara")) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(1...4, id: \.self) { variant in
                                VariantButton(
                                    variant: variant,
                                    type: selectedType,
                                    isSelected: selectedVariant == variant
                                ) {
                                    selectedVariant = variant
                                }
                            }
                        }
                        .padding(.vertical, 8)
                    }
                }
                
                // Notas
                Section(header: Text("Notas (Opcional)")) {
                    TextEditor(text: $notes)
                        .frame(minHeight: 100)
                }
                
                // Favorito
                Section {
                    Toggle("Marcar como favorito", isOn: $isFavorite)
                }
                
                // Preview
                Section(header: Text("Preview")) {
                    HStack {
                        Spacer()
                        VStack(spacing: 12) {
                            // Tea Preview (placeholder)
                            Image(systemName: selectedType == .teaBag ? "square.fill" : "cup.and.saucer.fill")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80, height: 80)
                                .foregroundColor(getColorForVariant(selectedVariant))
                            
                            Text(teaName.isEmpty ? "Meu Chá" : teaName)
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            Text(selectedType.displayName)
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            if isFavorite {
                                Image(systemName: "star.fill")
                                    .foregroundColor(.yellow)
                            }
                        }
                        Spacer()
                    }
                    .padding(.vertical, 20)
                }
            }
            .navigationTitle("Novo Chá")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("Salvar") {
                        saveTea()
                    }
                    .disabled(teaName.isEmpty)
                }
            }
            .alert("Nome obrigatório", isPresented: $showingAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Por favor, insira um nome para o chá")
            }
        }
    }
    
    // MARK: - Methods
    private func saveTea() {
        guard !teaName.trimmingCharacters(in: .whitespaces).isEmpty else {
            showingAlert = true
            return
        }
        
        let notesText = notes.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : notes
        onSave?(teaName, selectedType, selectedVariant, notesText)
        dismiss()
    }
    
    private func getColorForVariant(_ variant: Int) -> Color {
        switch variant {
        case 1: return .brown
        case 2: return .green
        case 3: return .orange
        case 4: return .purple
        default: return .brown
        }
    }
}

// MARK: - VariantButton Component
struct VariantButton: View {
    let variant: Int
    let type: TeaType
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: type == .teaBag ? "square.fill" : "cup.and.saucer.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 50, height: 50)
                    .foregroundColor(getColor())
                
                Text("Opção \(variant)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
            .background(isSelected ? Color.gray.opacity(0.2) : Color.clear)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? Color.accentColor : Color.clear, lineWidth: 2)
            )
        }
    }
    
    private func getColor() -> Color {
        switch variant {
        case 1: return .brown
        case 2: return .green
        case 3: return .orange
        case 4: return .purple
        default: return .brown
        }
    }
}

// MARK: - Preview
#Preview {
    AddTeaView(collectionId: UUID())
}
