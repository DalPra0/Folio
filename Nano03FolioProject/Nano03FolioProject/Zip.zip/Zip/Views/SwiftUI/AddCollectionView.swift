//
//  AddCollectionView.swift
//  Nano03FolioProject
//
//  Created by Lucas Dal Pra Brascher on 01/10/25.
//

import SwiftUI

/// View SwiftUI para adicionar uma nova coleção
struct AddCollectionView: View {
    // MARK: - Environment
    @Environment(\.dismiss) var dismiss
    
    // MARK: - State
    @State private var collectionName: String = ""
    @State private var selectedBoxColor: Int = 1
    @State private var showingAlert: Bool = false
    
    // MARK: - Callback
    var onSave: ((String, Int) -> Void)?
    
    // MARK: - Body
    var body: some View {
        NavigationView {
            Form {
                // Nome da Coleção
                Section(header: Text("Nome da Coleção")) {
                    TextField("Ex: Chás da Manhã", text: $collectionName)
                        .autocapitalization(.words)
                }
                
                // Cor da Caixa
                Section(header: Text("Escolha a Cor da Caixa")) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(1...4, id: \.self) { colorIndex in
                                BoxColorButton(
                                    colorIndex: colorIndex,
                                    isSelected: selectedBoxColor == colorIndex
                                ) {
                                    selectedBoxColor = colorIndex
                                }
                            }
                        }
                        .padding(.vertical, 8)
                    }
                }
                
                // Preview
                Section(header: Text("Preview")) {
                    HStack {
                        Spacer()
                        VStack(spacing: 12) {
                            // Box Preview (placeholder)
                            Image(systemName: "shippingbox.fill")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 100, height: 100)
                                .foregroundColor(getColorForBox(selectedBoxColor))
                            
                            Text(collectionName.isEmpty ? "Minha Coleção" : collectionName)
                                .font(.headline)
                                .foregroundColor(.primary)
                        }
                        Spacer()
                    }
                    .padding(.vertical, 20)
                }
            }
            .navigationTitle("Nova Coleção")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("Salvar") {
                        saveCollection()
                    }
                    .disabled(collectionName.isEmpty)
                }
            }
            .alert("Nome obrigatório", isPresented: $showingAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Por favor, insira um nome para a coleção")
            }
        }
    }
    
    // MARK: - Methods
    private func saveCollection() {
        guard !collectionName.trimmingCharacters(in: .whitespaces).isEmpty else {
            showingAlert = true
            return
        }
        
        onSave?(collectionName, selectedBoxColor)
        dismiss()
    }
    
    private func getColorForBox(_ variant: Int) -> Color {
        switch variant {
        case 1: return .brown
        case 2: return .orange
        case 3: return .green
        case 4: return .blue
        default: return .brown
        }
    }
}

// MARK: - BoxColorButton Component
struct BoxColorButton: View {
    let colorIndex: Int
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: "shippingbox.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 60, height: 60)
                    .foregroundColor(getColor())
                
                Text("Cor \(colorIndex)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
            .background(isSelected ? Color.gray.opacity(0.2) : Color.clear)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? Color.accentColor : Color.clear, lineWidth: 2)
            )
        }
    }
    
    private func getColor() -> Color {
        switch colorIndex {
        case 1: return .brown
        case 2: return .orange
        case 3: return .green
        case 4: return .blue
        default: return .brown
        }
    }
}

// MARK: - Preview
#Preview {
    AddCollectionView()
}
